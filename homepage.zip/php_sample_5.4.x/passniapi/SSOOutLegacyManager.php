<?php

/*********************************************************************************
*  ���ϸ�        : SSOLegacyManager.php
*  ����          : Zend extention library PHP API for SSO PassNiApi
*  �ۼ���        : remipa@paran.com
*  Ȯ����        : 
*
*  Author         Date			Description
*  ----------  --------------  ---------------------------------------------
*	remipa		2007-01-05		Initial Version - session ���
*	remipa		2007-03-19		���Ǻ����� ����
*	remipa		2007-06-08		KEYTYPE("dynamic" ) Ȯ�� - ��ƼSSO����
*	 
* [����] �� ������ ���Ƿ� �������� ���ʽÿ�.	
*
*********************************************************************************/

	include "passniapizend.php";
	
/*********************************************************************************
* session_start(); ���� �ݵ�� HTML HEADER ������ ��ġ�ؾ� �մϴ�.
*********************************************************************************/
	session_start();

	
/******************************************************
* php.ini ����
*
* [case 1] register_long_arrays = Off
*	
*	$cltid = $_POST["cltid"];
*	$argv1 = $_POST["argv1"];
*	$argv2 = $_POST["argv2"];
*
* [case 2] register_long_arrays = On
*	
*	global $HTTP_POST_VARS;
*	$cltid = $HTTP_POST_VARS["cltid"];
*	$argv1 = $HTTP_POST_VARS["argv1"];
*	$argv2 = $HTTP_POST_VARS["argv2"];
*******************************************************/
	$keytype = $_POST["keytype"];
	$appid = $_POST["app_id"];
	$sso_svrip = $_POST["sso_svrip"];
	$redirect_url = $_POST["redirect_url"];

	$enc_mkey = $_POST["SSOMasterKey"];
	$argv1 = $_POST["argv1"];
	$argv2 = $_POST["argv2"];

	if($keytype == "dynamic")
		$sso_result = php_passniapi_decrypt_dynamicEx( $appid, $sso_svrip, $enc_mkey,  $argv1, $argv2 );
	else
		$sso_result = php_passniapi_decrypt_extranetEx( $enc_mkey,  $argv1, $argv2 );

	if( $sso_result != PASSNI_RET_OK )
	{
		/* failed
		*/		
		$_SESSION['sso_result'] = $sso_result;
	}
	else
	{	
		/* succeed
		*/
		$_SESSION['sso_result'] = $sso_result;
		$_SESSION['userid'] = $argv1;
		$_SESSION['sso_ret_url'] = $returl;
	}

	
	if(is_null($redirect_url) || strlen($redirect_url)<=0)
		$redirect_url = $g_redirecturl;
	
	echo("<script>location.replace('$redirect_url');</script>");

?>
